import math

import rclpy
from rclpy.node import Node
from rclpy.executors import ExternalShutdownException
from sensor_msgs.msg import Imu
from geometry_msgs.msg import Vector3Stamped
from std_msgs.msg import Float32, Bool


class DepthFusion(Node):
    """Dead-reckon depth between sparse MS5837 reads using the BNO055.

    The MS5837 on this vehicle only delivers ~1.2 accepted reads/s with gaps
    up to ~5 s, and some bus corruption survives the driver's range checks
    (e.g. a bit-shifted D1 that lands ~0.5 m off; see sanity_5min.log). The
    BNO055 publishes 20 Hz gravity-removed body-frame acceleration plus an
    absolute orientation quaternion. This node:

      * extracts the vertical component of the body-frame acceleration and
        double-integrates it to propagate depth between pressure reads.
        The vertical direction comes from the BNO055's own gravity vector
        (/imu/gravity, projected in the body frame), so ANY mounting
        orientation -- including one that changes between missions -- is
        handled without axis conventions; when no fresh gravity sample is
        available it falls back to rotating by the orientation quaternion
        (mathematically equivalent, but trusts quaternion conventions),
      * gates every incoming pressure read against that prediction (window
        grows with the time since the last accepted read, capped so far-out
        garbage never gets in), with an N-read consensus override: a run of
        `consensus_count` (default 4) consecutive out-of-gate reads that all
        agree with each other re-anchors the filter, so a drifted prediction
        can never lock out real data, and
      * on each accepted read snaps depth to the measurement and re-derives
        vertical velocity from consecutive accepted reads, which also kills
        any velocity drift accumulated during the gap.

    Subscribes /depth_raw (driver) + /imu, publishes the fused estimate on
    /depth at IMU rate, so downstream (sensor_bridge -> nav) sees a
    continuous depth instead of a 1 Hz signal with multi-second holes.

    Two drift guards on the pure double integral, both disable-able:
      * accel bias is tracked as a slow EMA of the vertical acceleration
        (the sub's mean vertical accel is ~0 on any control timescale), and
      * velocity leaks toward 0 with a long time constant, bounding the
        worst-case runaway if the sensor dies outright.
    Until the first accepted pressure read there is no absolute reference,
    so nothing is published (same downstream behavior as a dead sensor).
    """

    def __init__(self):
        super().__init__('depth_fusion')

        # World +Z is up in the BNO055 fusion frame => depth (down+) second
        # derivative = -a_world_z. Set -1.0 only if the frame proves flipped.
        # Applies to both the gravity-projection and quaternion paths (the
        # BNO055 gravity vector points UP, i.e. reads (0,0,+9.81) when flat).
        self.world_z_sign = float(self.declare_parameter('world_z_sign', 1.0).value)
        # Max age of the last gravity sample before falling back to the
        # quaternion. Attitude changes slowly relative to this, so a slightly
        # stale vertical is fine; a corrupted one is not (gated upstream).
        self.grav_max_age = float(self.declare_parameter('grav_max_age_s', 1.0).value)
        # Accel bias EMA time constant (s); 0 disables.
        self.bias_tau = float(self.declare_parameter('bias_tau', 30.0).value)
        # Velocity leak toward 0 (s); 0 disables. Bounds drift if depth dies.
        self.vel_leak_tau = float(self.declare_parameter('vel_leak_tau', 10.0).value)
        # Physical clamps: the vehicle can't exceed these vertically, so
        # anything past them is bus corruption, not motion. max_accel guards
        # the integrator against single corrupt IMU samples (bus 1 silently
        # corrupts ~7% of ACKed reads; one 5 m/s^2 spike at dt=0.1 s would
        # kick velocity by 0.5 m/s).
        self.max_speed = float(self.declare_parameter('max_speed', 1.5).value)
        self.max_accel = float(self.declare_parameter('max_accel', 4.0).value)
        # Don't integrate across IMU dropouts longer than this (s).
        self.max_imu_dt = float(self.declare_parameter('max_imu_dt', 0.5).value)
        # Innovation gate: accept a read if |meas - pred| <= base + rate*gap,
        # capped at gate_max. The cap matters: the bench run showed corrupt
        # reads landing anywhere in +-100 m, so an uncapped gate after a
        # multi-second gap admits ~1 m garbage. A capped gate can't lock out
        # real data because of the consensus override below.
        self.gate_base = float(self.declare_parameter('gate_base_m', 0.2).value)
        self.gate_rate = float(self.declare_parameter('gate_rate_m_per_s', 0.4).value)
        self.gate_max = float(self.declare_parameter('gate_max_m', 0.5).value)
        # Consensus override: a run of `consensus_count` consecutive
        # out-of-gate reads that all agree with EACH OTHER (each within
        # consensus_tol of the previous one in the run) re-anchors the
        # filter -- if the prediction has drifted (or the first fix was
        # bad), the sensor wins on evidence rather than on a timeout. Raised
        # from 2 to 4: bench testing after the depth-sensor solder rework
        # showed a specific corruption pattern that recurs as the SAME wrong
        # value across independent reads (not random scatter), so two
        # agreeing corrupt reads in a row turned out not to be rare enough --
        # requiring 4 in a row makes a false re-anchor on repeat-corruption
        # far less likely while a real step (e.g. actually diving) still
        # confirms itself within a few reads.
        self.consensus_tol = float(self.declare_parameter('consensus_tol_m', 0.25).value)
        self.consensus_count = int(self.declare_parameter('consensus_count', 4).value)
        self.pending_max_age = float(self.declare_parameter('pending_max_age_s', 2.0).value)
        # First fix only: the vehicle is static at startup, so consensus_count
        # reads agreeing across a much longer window are still strong
        # evidence. Without this a badly degraded bus (reads tens of seconds
        # apart) can never anchor the filter at all.
        self.first_fix_max_age = float(self.declare_parameter('first_fix_max_age_s', 15.0).value)
        # Velocity from consecutive accepted reads: max usable gap and blend.
        # The blend is scaled by the gap (cm-level read noise over a short
        # gap is a huge velocity, so short gaps get little say).
        self.vel_meas_max_gap = float(self.declare_parameter('vel_meas_max_gap_s', 3.0).value)
        self.vel_blend = float(self.declare_parameter('vel_blend', 0.7).value)
        # Coarse physical envelope (m, down+) for the ANCHOR-COMMIT guard. The
        # driver's tight per-read magnitude gate stops most corruption upstream,
        # but corruption on this bus recurs BIT-FOR-BIT, so consensus_count
        # identical corrupt reads could still agree and force a false re-anchor
        # (or a bad first fix, where there is no prediction to gate against).
        # Refusing to (re-)anchor on any z outside this wide physical bound makes
        # that impossible no matter how many times a bad value repeats. Wider
        # than the driver gate on purpose (this is a backstop, not the primary
        # filter); -1.0 tolerates a bench sensor in air (~-0.3 m).
        self.depth_env_min = float(self.declare_parameter('depth_envelope_min_m', -1.0).value)
        self.depth_env_max = float(self.declare_parameter('depth_envelope_max_m', 8.0).value)
        # Staleness deadman. dr_max_age: once the last accepted pressure fix is
        # older than this, /depth is dead-reckoned-only and flagged stale (the
        # healthy gap ran up to ~7.6 s, so 8 s marks genuinely-degraded). Past
        # dead_reckon_hard_limit the double integral is FROZEN (vel->0, depth
        # held) so a multi-minute blackout can't drift the estimate tens of
        # metres while looking healthy -- bounded+stale beats smooth+wrong.
        self.dr_max_age = float(self.declare_parameter('dr_max_age_s', 8.0).value)
        self.dr_hard_limit = float(self.declare_parameter('dead_reckon_hard_limit_s', 20.0).value)
        # Startup watchdog: if no /depth_raw arrives within this window the
        # driver isn't running or the /depth->/depth_raw remap is missing, so
        # the node would silently never anchor. Make that loud.
        self.raw_watchdog_s = float(self.declare_parameter('raw_watchdog_s', 20.0).value)

        self.pub_depth = self.create_publisher(Float32, '/depth', 10)
        # meas - pred at each accepted read; a live health/tuning signal.
        self.pub_innov = self.create_publisher(Float32, '/depth_fusion/innovation', 10)
        # Fused vertical velocity (m/s, down+). sensor_bridge maps this into
        # /sensors/velocity.linear.z so the nav depth PID gets its D-term back
        # (without a DVL the velocity twist was all zeros -> PI-only depth
        # control and vertical completion gates that were trivially true).
        self.pub_vz = self.create_publisher(Float32, '/depth_fusion/velocity_z', 10)
        # Health flag: True whenever /depth is untrustworthy (no fix yet, or
        # the last fix is older than dr_max_age). sensor_bridge forwards this
        # so the nav / a human can react instead of trusting a stale estimate.
        self.pub_stale = self.create_publisher(Bool, '/depth_fusion/stale', 10)

        self.create_subscription(Imu, '/imu', self.on_imu, 10)
        self.create_subscription(Vector3Stamped, '/imu/gravity', self.on_gravity, 10)
        self.create_subscription(Float32, '/depth_raw', self.on_depth_raw, 10)

        self._depth = None       # fused depth (m, down+); None until first fix
        self._vel = 0.0          # fused vertical velocity (m/s, down+)
        self._bias = 0.0         # learned accel bias (m/s^2, depth frame)
        self._last_imu_t = None
        self._last_accept_t = None
        self._last_accept_z = None
        self._pending_hist = []  # [(t, z), ...] run of agreeing out-of-gate reads
        self._accel_hist = []    # last 3 vertical accels; median kills spikes
        self._gravity = None     # (t, unit "up" vector in body frame)
        self._last_quat = None   # normalized (w,x,y,z) from the last IMU msg
        self._accepted = 0
        self._rejected = 0
        self._reanchors = 0
        self._n_grav = 0         # IMU samples resolved via gravity projection
        self._n_quat = 0         # ... via quaternion fallback
        self._raw_count = 0      # /depth_raw msgs seen (startup watchdog)
        self._warned_no_raw = False
        self._frozen = False     # true while dead-reckoning past the hard limit

        # Publish on a fixed clock rather than from the sensor callbacks, so
        # a simultaneous IMU + depth dropout can't leave a hole in /depth --
        # downstream sees a continuous stream; during a total blackout the
        # estimate just freezes (velocity leaks to 0), which is the same
        # behavior the nav already accepts from synthetic_depth mode.
        self.create_timer(0.05, self.on_publish_timer)
        self.create_timer(10.0, self.on_status_timer)
        self.create_timer(self.raw_watchdog_s, self.on_raw_watchdog)
        self.get_logger().info('depth fusion node started (waiting for first pressure fix)')

    def _now(self):
        return self.get_clock().now().nanoseconds * 1e-9

    def _in_envelope(self, z):
        return self.depth_env_min <= z <= self.depth_env_max

    def on_raw_watchdog(self):
        if self._raw_count == 0 and not self._warned_no_raw:
            self._warned_no_raw = True
            self.get_logger().error(
                'no /depth_raw in %.0fs after start -- is depth_sensor running '
                'and remapped (/depth->/depth_raw)? depth will NEVER anchor.'
                % self.raw_watchdog_s)

    def on_imu(self, msg):
        t = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        if t <= 0.0:
            t = self._now()
        if self._last_imu_t is None:
            self._last_imu_t = t
            return
        dt = t - self._last_imu_t
        self._last_imu_t = t
        if dt <= 0.0 or dt > self.max_imu_dt:
            return  # clock jump or IMU dropout: hold rather than integrate

        # Keep the latest valid quaternion as the fallback vertical reference
        # (a zero/corrupt one is published as all-zeros by the driver).
        q = msg.orientation
        n2 = q.w * q.w + q.x * q.x + q.y * q.y + q.z * q.z
        if n2 >= 1e-6:
            n = math.sqrt(n2)
            self._last_quat = (q.w / n, q.x / n, q.y / n, q.z / n)

        a = msg.linear_acceleration
        a_up = self._vertical_accel(t, a)
        if a_up is None:
            return  # no usable vertical reference yet
        a_depth = -self.world_z_sign * a_up

        # Median-of-3 before integrating: a silently-corrupted accel sample
        # (ACKed read, wrong bytes) appears as a one-tick spike, and the
        # median rejects it outright at the cost of one sample of lag.
        self._accel_hist.append(a_depth)
        if len(self._accel_hist) > 3:
            self._accel_hist.pop(0)
        a_med = sorted(self._accel_hist)[len(self._accel_hist) // 2]

        if self.bias_tau > 0.0:
            alpha = dt / (self.bias_tau + dt)
            self._bias += alpha * (a_med - self._bias)
        a_est = a_med - self._bias
        a_est = max(-self.max_accel, min(self.max_accel, a_est))

        if self._depth is None:
            return  # bias keeps learning pre-fix, but there's nothing to propagate

        # Bounded-drift freeze: past the hard limit with no pressure fix, stop
        # integrating and hold the last depth (vel->0). Without a pressure
        # reference, real descent and accumulated bias are indistinguishable,
        # so a free-running double integral would wander tens of metres over a
        # multi-minute blackout while /depth still looked healthy. Freezing
        # keeps it bounded; the stale flag marks it untrustworthy so the
        # buoyant hull can be commanded up rather than held at a phantom depth.
        if (self._last_accept_t is not None
                and (self._now() - self._last_accept_t) > self.dr_hard_limit):
            self._vel = 0.0
            if not self._frozen:
                self._frozen = True
                self.get_logger().warn(
                    'depth dead-reckon exceeded %.0fs: freezing estimate at %.3f m'
                    % (self.dr_hard_limit, self._depth))
            return

        self._vel += a_est * dt
        if self.vel_leak_tau > 0.0:
            self._vel *= math.exp(-dt / self.vel_leak_tau)
        self._vel = max(-self.max_speed, min(self.max_speed, self._vel))
        self._depth += self._vel * dt + 0.5 * a_est * dt * dt

    def _vertical_accel(self, t, a):
        """Upward component of the body-frame linear acceleration `a`.

        Primary: project onto the BNO055-measured gravity direction (the
        actual local vertical in body coordinates) -- correct for any
        mounting orientation with no quaternion axis/ordering assumptions.
        Fallback: world-Z row of the quaternion rotation, for cycles where
        the extra gravity read failed on the flaky bus. Returns None when
        neither reference is usable.
        """
        g = self._gravity
        if g is not None and (t - g[0]) <= self.grav_max_age:
            self._n_grav += 1
            return a.x * g[1] + a.y * g[2] + a.z * g[3]

        q = self._last_quat
        if q is not None:
            w, x, y, z = q
            self._n_quat += 1
            return (2.0 * (x * z - w * y) * a.x
                    + 2.0 * (y * z + w * x) * a.y
                    + (1.0 - 2.0 * (x * x + y * y)) * a.z)
        return None

    def on_gravity(self, msg):
        t = msg.header.stamp.sec + msg.header.stamp.nanosec * 1e-9
        if t <= 0.0:
            t = self._now()
        v = msg.vector
        n = math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z)
        if n < 1e-3:
            return
        # BNO055 gravity output points UP (reads (0,0,+9.81) lying flat).
        self._gravity = (t, v.x / n, v.y / n, v.z / n)

    def on_depth_raw(self, msg):
        now = self._now()
        z = float(msg.data)
        self._raw_count += 1

        if self._depth is None:
            # No anchor yet: require consensus_count agreeing reads, all inside
            # the physical envelope, so neither a single corrupt read nor a run
            # of repeating out-of-envelope corruption can set the initial depth
            # (there is no prediction to innovation-gate against on first fix).
            if not self._in_envelope(z):
                self.get_logger().warn(
                    'first-fix candidate %.3f m out of envelope [%.1f, %.1f]; ignoring'
                    % (z, self.depth_env_min, self.depth_env_max),
                    throttle_duration_sec=5.0)
                return
            if self._consensus(now, z, max_age=self.first_fix_max_age):
                self._pending_hist = []
                self._accept(now, z, v_meas=None)
                self.get_logger().info('first pressure fix: %.3f m' % z)
            return

        gap = now - self._last_accept_t
        innov = z - self._depth
        gate = min(self.gate_base + self.gate_rate * gap, self.gate_max)

        if abs(innov) <= gate:
            self._pending_hist = []
            self.pub_innov.publish(Float32(data=float(innov)))
            v_meas = None
            if 0.0 < gap <= self.vel_meas_max_gap:
                # Average velocity across the gap replaces the integrated
                # one -- this is what zeroes out accumulated drift. Blend
                # strength scales with the gap (a cm of read noise over a
                # short gap is a large phantom velocity).
                v_raw = (z - self._last_accept_z) / gap
                v_raw = max(-self.max_speed, min(self.max_speed, v_raw))
                blend = self.vel_blend * min(1.0, gap)
                v_meas = blend * v_raw + (1.0 - blend) * self._vel
            self._accept(now, z, v_meas)
            return

        if not self._in_envelope(z):
            # Failed the innovation gate AND outside the physical envelope:
            # pure corruption. Reset the consensus streak so it can never
            # accumulate toward a re-anchor, no matter how often the SAME bad
            # value repeats (this bus's corruption recurs bit-for-bit).
            self._rejected += 1
            self._pending_hist = []
            self.get_logger().warn(
                'rejected out-of-envelope depth %.3f m (envelope [%.1f, %.1f], gap %.2fs)'
                % (z, self.depth_env_min, self.depth_env_max, gap),
                throttle_duration_sec=2.0)
            return

        if self._consensus(now, z):
            # consensus_count consecutive reads agree with each other but not
            # with the prediction: the prediction is what's wrong. Re-anchor
            # to the sensor and take the slope across the agreeing run as
            # velocity (widest available baseline = least noise-sensitive).
            t_p, z_p = self._pending_hist[0]
            self._pending_hist = []
            self._reanchors += 1
            v_meas = None
            if now - t_p >= 0.15:
                v_meas = (z - z_p) / (now - t_p)
                v_meas = max(-self.max_speed, min(self.max_speed, v_meas))
            self.get_logger().warn(
                're-anchor to %.3f m on %d-read consensus (pred was %.3f, innov %+.3f)'
                % (z, self.consensus_count, self._depth, innov))
            self._accept(now, z, v_meas)
            return

        self._rejected += 1
        self.get_logger().warn(
            'rejected depth read %.3f m (pred %.3f, innov %+.3f > gate %.3f, gap %.2fs)'
            % (z, self._depth, innov, gate, gap),
            throttle_duration_sec=2.0)

    def _consensus(self, now, z, max_age=None):
        """Extend the pending run of mutually-agreeing out-of-gate reads
        with (now, z); True once the run reaches consensus_count entries.

        Each new read must land within max_age of, and within
        consensus_tol of, the previous read in the run -- otherwise the
        run resets and starts over at this read. This is always called
        exactly once per incoming out-of-gate read, so it both updates and
        queries the streak state as a side effect.
        """
        if max_age is None:
            max_age = self.pending_max_age
        if (self._pending_hist
                and now - self._pending_hist[-1][0] <= max_age
                and abs(z - self._pending_hist[-1][1]) <= self.consensus_tol):
            self._pending_hist.append((now, z))
        else:
            self._pending_hist = [(now, z)]
        return len(self._pending_hist) >= self.consensus_count

    def _accept(self, now, z, v_meas):
        self._accepted += 1
        self._depth = z
        if v_meas is not None:
            self._vel = v_meas
        self._last_accept_t = now
        self._last_accept_z = z
        if self._frozen:
            self._frozen = False
            self.get_logger().info('depth un-frozen: fresh pressure fix %.3f m' % z)
        self.pub_depth.publish(Float32(data=float(self._depth)))

    def _is_stale(self):
        return (self._last_accept_t is None
                or (self._now() - self._last_accept_t) > self.dr_max_age)

    def on_publish_timer(self):
        if self._depth is not None:
            self.pub_depth.publish(Float32(data=float(self._depth)))
            self.pub_vz.publish(Float32(data=float(self._vel)))
        # Health flag every tick (also before first fix => stale=True), so a
        # subscriber that starts late still learns the current trust state.
        self.pub_stale.publish(Bool(data=bool(self._is_stale())))

    def on_status_timer(self):
        if self._depth is None:
            self.get_logger().info('no pressure fix yet (accepted=0)')
            return
        age = self._now() - self._last_accept_t
        health = 'FROZEN' if self._frozen else ('STALE' if self._is_stale() else 'ok')
        self.get_logger().info(
            'depth %.3f m [%s], vel %+.3f m/s, bias %+.4f m/s^2, accepted %d, rejected %d, '
            're-anchors %d, vertical ref grav/quat %d/%d, last fix %.1fs ago'
            % (self._depth, health, self._vel, self._bias, self._accepted, self._rejected,
               self._reanchors, self._n_grav, self._n_quat, age))


def main(args=None):
    rclpy.init(args=args)

    node = DepthFusion()

    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
