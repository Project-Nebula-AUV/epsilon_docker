try:
    import smbus2 as smbus
except:
    print('Try sudo apt-get install python-smbus2')

import fcntl
from time import sleep

# Models
MODEL_02BA = 0
MODEL_30BA = 1
MODEL_UNKNOWN = 255

# context: https://github.com/ArduPilot/ardupilot/pull/29122#issuecomment-2877269114
MS5837_02BA_MAX_SENSITIVITY = 49000;
MS5837_02BA_30BA_SEPARATION = 37000;
MS5837_30BA_MIN_SENSITIVITY = 26000;

# Oversampling options
OSR_256  = 0
OSR_512  = 1
OSR_1024 = 2
OSR_2048 = 3
OSR_4096 = 4
OSR_8192 = 5

# kg/m^3 convenience
DENSITY_FRESHWATER = 997
DENSITY_SALTWATER = 1029

# Conversion factors (from native unit, mbar)
UNITS_Pa     = 100.0
UNITS_hPa    = 1.0
UNITS_kPa    = 0.1
UNITS_mbar   = 1.0
UNITS_bar    = 0.001
UNITS_atm    = 0.000986923
UNITS_Torr   = 0.750062
UNITS_psi    = 0.014503773773022

# Valid units
UNITS_Centigrade = 1
UNITS_Farenheit  = 2
UNITS_Kelvin     = 3


class MS5837(object):

    # Registers
    _MS5837_ADDR             = 0x76
    _MS5837_RESET            = 0x1E
    _MS5837_ADC_READ         = 0x00
    _MS5837_PROM_READ        = 0xA0
    _MS5837_CONVERT_D1_256   = 0x40
    _MS5837_CONVERT_D2_256   = 0x50

    # Per-fd kernel I2C_TIMEOUT (see set_i2c_timeout below). This bus's
    # DesignWare I2C driver defaults to ~1.024s per stuck/timed-out
    # transaction (measured 2026-07-04: dt=1.0240s on every TimeoutError).
    # A genuine successful read consistently completes in ~35-40ms, so
    # 100ms leaves ample margin without waiting anywhere near a full
    # second to find out a transaction is dead. NOTE: an interleaved on-bus
    # A/B test (2026-07-04) showed this does NOT raise the sustained valid-
    # reads/sec on this specific bus -- retrying faster just confirms
    # "still wedged" faster, it doesn't get more bits through (the fault is
    # a fixed physical duty-cycle, see robosub-i2c-bus-health memory) -- so
    # this is a reconnect-responsiveness / wasted-blocking-time fix, not a
    # throughput fix. depth_sensor.py exposes it as i2c_timeout_ms.
    _I2C_TIMEOUT_MS = 100
    _I2C_TIMEOUT_IOCTL = 0x0702  # linux i2c-dev.h I2C_TIMEOUT, units of 10ms

    def __init__(self, model=MODEL_UNKNOWN, bus=1):
        self._model = model

        try:
            self._bus = smbus.SMBus(bus)
        except:
            print("Bus %d is not available."%bus)
            print("Available busses are listed as /dev/i2c*")
            self._bus = None

        self.set_i2c_timeout(self._I2C_TIMEOUT_MS)

        self._fluidDensity = DENSITY_FRESHWATER
        self._pressure = 0
        self._temperature = 0
        self._D1 = 0
        self._D2 = 0

    def set_i2c_timeout(self, timeout_ms):
        """Override the kernel i2c-dev per-transaction timeout via the
        standard Linux I2C_TIMEOUT ioctl (units of 10ms). Per-fd, userspace-
        only -- no root/kernel config needed. Not fatal if unsupported
        (falls back to whatever the kernel default is, ~1.024s here).
        """
        if self._bus is None:
            return
        try:
            fcntl.ioctl(self._bus.fd, self._I2C_TIMEOUT_IOCTL,
                        max(1, int(round(timeout_ms / 10.0))))
        except OSError:
            pass

    def init(self):
        if self._bus is None:
            "No bus!"
            return False

        self._bus.write_byte(self._MS5837_ADDR, self._MS5837_RESET)

        # Wait for reset to complete
        sleep(0.01)

        self._C = []

        # Read calibration values and CRC
        for i in range(7):
            c = self._bus.read_word_data(self._MS5837_ADDR, self._MS5837_PROM_READ + 2*i)
            c =  ((c & 0xFF) << 8) | (c >> 8) # SMBus is little-endian for word transfers, we need to swap MSB and LSB
            self._C.append(c)

        crc = (self._C[0] & 0xF000) >> 12
        if crc != self._crc4(self._C):
            print("PROM read error, CRC failed!")
            return False

        if self._model == MODEL_UNKNOWN:
            self.auto_detect_model()

        return True

    def auto_detect_model(self):
        """ Automatically detect sensor variant, with a heuristic threshold.

        Details in https://github.com/ArduPilot/ardupilot/pull/29122#issuecomment-2877269114x

        TODO: include detection of product version / package type, from PROM Word 0, per
        https://github.com/ArduPilot/ardupilot/pull/29122#pullrequestreview-2837597764
        """
        pressure_sensitivity = self._C[1]
        if MS5837_30BA_MIN_SENSITIVITY <= pressure_sensitivity <= MS5837_02BA_30BA_SEPARATION:
            self._model = MODEL_30BA
        elif MS5837_02BA_30BA_SEPARATION < pressure_sensitivity <= MS5837_02BA_MAX_SENSITIVITY:
            self._model = MODEL_02BA
        else:
            self._model = MODEL_UNKNOWN

    def _read_adc(self):
        # The 3 ADC bytes must be clocked out in a single continuous I2C
        # transaction; issuing them as separate read_byte() calls (each with
        # its own STOP/START) causes the sensor to NACK the 2nd and 3rd byte.
        return self._bus.read_i2c_block_data(self._MS5837_ADDR, self._MS5837_ADC_READ, 3)

    # Operating-envelope gate (pool defaults). The old rated-envelope bounds
    # (-1000..35000 mbar, -50..100 C) were so loose that every recurring bus-
    # corruption signature passed as "real depth": 2822 mbar (18.5 m),
    # 5906 mbar (50 m), 12074 mbar (113 m), 26874 mbar (264 m), 944 mbar
    # (-0.7 m) and impossible -15/45 C temps. A pool run is ~1013 mbar
    # (surface) to ~1600 mbar (6 m) at 20-30 C, so these tight defaults reject
    # the corruption as a fast read()==False (which the IMU dead-reckon + the
    # fusion 4-read consensus already absorb) without clipping a genuine
    # 0-6 m reading. depth_sensor.py overrides these per-instance from ROS
    # params, so a deeper/higher-altitude venue widens them with no code edit.
    # NOTE: lower bound 950 mbar assumes a near-sea-level venue (surface
    # ~1013 mbar); raise press_min_mbar for a high-altitude pool.
    _PRESSURE_MIN_MBAR = 950.0
    _PRESSURE_MAX_MBAR = 1800.0
    _TEMP_MIN_C = 10.0
    _TEMP_MAX_C = 40.0

    # Per-conversion ADC wait = max(_conv_floor, conv_time + _conv_margin).
    # conv_time is the datasheet max (OSR_256 ~= 0.64 ms), so the old 10 ms
    # floor padded each of the two conversions ~16x longer than needed --
    # ~20 ms of a ~21 ms read() was idle wait. Lowering the floor multiplies
    # attempts/s (and thus valid reads/s during a cooperating bus). Floor too
    # low reads the ADC mid-conversion -> the 12074 mbar / -15 C corruption,
    # so it is swept empirically and kept a safe margin above real conversion.
    # depth_sensor.py overrides _conv_floor per-instance from a ROS param.
    _conv_floor = 0.01
    _conv_margin = 0.005

    @staticmethod
    def _adc_value_corrupt(value):
        # A block read that gets cut off mid-transfer without the I2C driver
        # reporting an error leaves the bus either stuck low (reads back as
        # 0) or floating/pulled high (reads back as all-1s, i.e. 2^n - 1).
        # Both are electrically impossible as genuine 24-bit ADC output.
        return value == 0 or (value & (value + 1)) == 0

    def read(self, oversampling=OSR_1024):
        if self._bus is None:
            print("No bus!")
            return False

        if oversampling < OSR_256 or oversampling > OSR_8192:
            print("Invalid oversampling option!")
            return False

        # Request D1 conversion (pressure)
        self._bus.write_byte(self._MS5837_ADDR, self._MS5837_CONVERT_D1_256 + 2*oversampling)

        # Maximum conversion time increases linearly with oversampling
        # max time (seconds) ~= 2.2e-6(x) where x = OSR = (2^8, 2^9, ..., 2^13)
        # Use conservative timing with extra margin

        conv_time = 2.5e-6 * 2**(8+oversampling)
        sleep(max(self._conv_floor, conv_time + self._conv_margin))

        d = self._read_adc()
        self._D1 = d[0] << 16 | d[1] << 8 | d[2]

        # Early bail: if D1 is already electrically corrupt (all-0 / all-1s),
        # skip the D2 convert + its conversion sleep + block read. On this
        # ~88%-fail bus most attempts fail, so not paying the second ~10 ms
        # conversion on a doomed read raises attempts/s (and thus valid
        # reads/s) with zero correctness change -- read() still returns False.
        if self._adc_value_corrupt(self._D1):
            return False

        # Small delay between D1 and D2 reads
        sleep(0.001)

        # Request D2 conversion (temperature)
        self._bus.write_byte(self._MS5837_ADDR, self._MS5837_CONVERT_D2_256 + 2*oversampling)

        # As above
        conv_time = 2.5e-6 * 2**(8+oversampling)
        sleep(max(self._conv_floor, conv_time + self._conv_margin))

        d = self._read_adc()
        self._D2 = d[0] << 16 | d[1] << 8 | d[2]

        if self._adc_value_corrupt(self._D1) or self._adc_value_corrupt(self._D2):
            return False

        # Calculate compensated pressure and temperature
        # using raw ADC values and internal calibration
        self._calculate()

        if not (self._PRESSURE_MIN_MBAR <= self._pressure <= self._PRESSURE_MAX_MBAR):
            return False
        if not (self._TEMP_MIN_C <= self.temperature() <= self._TEMP_MAX_C):
            return False

        return True

    def setFluidDensity(self, denisty):
        self._fluidDensity = denisty

    # Pressure in requested units
    # mbar * conversion
    def pressure(self, conversion=UNITS_mbar):
        return self._pressure * conversion

    # Temperature in requested units
    # default degrees C
    def temperature(self, conversion=UNITS_Centigrade):
        degC = self._temperature / 100.0
        if conversion == UNITS_Farenheit:
            return (9.0/5.0)*degC + 32
        elif conversion == UNITS_Kelvin:
            return degC + 273
        return degC

    # Depth relative to MSL pressure in given fluid density
    def depth(self):
        return (self.pressure(UNITS_Pa)-101300)/(self._fluidDensity*9.80665)

    # Altitude relative to MSL pressure
    def altitude(self):
        return (1-pow((self.pressure()/1013.25),.190284))*145366.45*.3048

    # Cribbed from datasheet
    def _calculate(self):
        OFFi = 0
        SENSi = 0
        Ti = 0

        dT = self._D2-self._C[5]*256
        if self._model == MODEL_02BA:
            SENS = self._C[1]*65536+(self._C[3]*dT)/128
            OFF = self._C[2]*131072+(self._C[4]*dT)/64
            self._pressure = (self._D1*SENS/(2097152)-OFF)/(32768)
        elif self._model == MODEL_30BA:
            SENS = self._C[1]*32768+(self._C[3]*dT)/256
            OFF = self._C[2]*65536+(self._C[4]*dT)/128
            self._pressure = (self._D1*SENS/(2097152)-OFF)/(8192)
        else:
            raise NotImplementedError("Cannot calculate pressure for unknown model type!")

        self._temperature = 2000+dT*self._C[6]/8388608

        # Second order compensation
        if self._model == MODEL_02BA:
            if (self._temperature/100) < 20: # Low temp
                Ti = (11*dT*dT)/(34359738368)
                OFFi = (31*(self._temperature-2000)*(self._temperature-2000))/8
                SENSi = (63*(self._temperature-2000)*(self._temperature-2000))/32

        else:
            if (self._temperature/100) < 20: # Low temp
                Ti = (3*dT*dT)/(8589934592)
                OFFi = (3*(self._temperature-2000)*(self._temperature-2000))/2
                SENSi = (5*(self._temperature-2000)*(self._temperature-2000))/8
                if (self._temperature/100) < -15: # Very low temp
                    OFFi = OFFi+7*(self._temperature+1500)*(self._temperature+1500)
                    SENSi = SENSi+4*(self._temperature+1500)*(self._temperature+1500)
            elif (self._temperature/100) >= 20: # High temp
                Ti = 2*(dT*dT)/(137438953472)
                OFFi = (1*(self._temperature-2000)*(self._temperature-2000))/16
                SENSi = 0

        OFF2 = OFF-OFFi
        SENS2 = SENS-SENSi

        if self._model == MODEL_02BA:
            self._temperature = (self._temperature-Ti)
            self._pressure = (((self._D1*SENS2)/2097152-OFF2)/32768)/100.0
        else:
            self._temperature = (self._temperature-Ti)
            self._pressure = (((self._D1*SENS2)/2097152-OFF2)/8192)/10.0

    # Cribbed from datasheet
    def _crc4(self, n_prom):
        n_rem = 0

        n_prom[0] = ((n_prom[0]) & 0x0FFF)
        n_prom.append(0)

        for i in range(16):
            if i%2 == 1:
                n_rem ^= ((n_prom[i>>1]) & 0x00FF)
            else:
                n_rem ^= (n_prom[i>>1] >> 8)

            for n_bit in range(8,0,-1):
                if n_rem & 0x8000:
                    n_rem = (n_rem << 1) ^ 0x3000
                else:
                    n_rem = (n_rem << 1)

        n_rem = ((n_rem >> 12) & 0x000F)

        self.n_prom = n_prom
        self.n_rem = n_rem

        return n_rem ^ 0x00

class MS5837_30BA(MS5837):
    def __init__(self, bus=1):
        MS5837.__init__(self, MODEL_30BA, bus)

class MS5837_02BA(MS5837):
    def __init__(self, bus=1):
        MS5837.__init__(self, MODEL_02BA, bus)
